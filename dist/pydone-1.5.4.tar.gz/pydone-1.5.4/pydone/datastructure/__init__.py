def help():
    print('stack, queue, bst')
