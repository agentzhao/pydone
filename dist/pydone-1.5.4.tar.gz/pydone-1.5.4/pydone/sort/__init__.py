def help():
    print('bubble, insertion, quick')

