name = "pydone"

print('pypi:   https://pypi.org/project/pydone/')
print('Github: https://github.com/Agentzhao/pydone/')
print('\'pydone.help()\' to learn how to use this module')

def help():
    print('''How to import and use functions:
from module import submodule
submodule.function(...)

-or-

import module.submodule
module.submodule.function(..)

Modules currently available:
sort, search, datastructures

Each algorithm will have teach and show function.
''')

def revold():
	print('wank')
