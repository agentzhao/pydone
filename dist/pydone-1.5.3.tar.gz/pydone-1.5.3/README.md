# pydone Package

# Made by Agentzhao and Revold

## How to Install
Make sure you have the latest version of **python** and **pip** installed. <br />
```py -m pip install pydone``` <br />
To update: <br />
```py -m pip install pydone==versionnumber``` <br />

## Version 1.5.3
Added a 'l' somewhere <br />
Added words <br />
Fixed Description

## Version 1.5.0
Added help functions <br />
Added teaching modules

## Version 1.4.1
More Bug Fixes

## Version 1.4.0
Bug Fixes for Description

## Version 1.3.0
Released data structure algorithms

## Version 1.2.0
Released searching algorithms

## Version 1.1.0
Released sorting algorithms

## Version 1.0.1
Released bubble sort algorithm <br />
Bug Fixes

## Version 1.0
Released pydone in beta <br />
Tested revold()