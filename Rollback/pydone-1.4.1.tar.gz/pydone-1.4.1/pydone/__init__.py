name = "pydone"

print('pypi:   https://pypi.org/project/pydone/')
print('Github: https://github.com/Agentzhao/pydone')

def help():
        print('sort, search, datastructure')

def revold():
	print('wank')
