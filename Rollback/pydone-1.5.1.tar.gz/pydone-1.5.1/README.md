# pydone Package

# Made by Agentzhao and Revold

## How to Install
### Make sure you have the latest version of __python__ and __pip__ installed.
###     py -m pip install pydone
### to update:
###     py -m pip install pydone==versionnumber

# Version 1.5.1
### Added a 'l' somewhere
### Added more words

# Version 1.5.0
### Added help functions
### Added teaching modules

# Version 1.4.1
### More Bug Fixes

# Version 1.4.0
### Bug Fixes for Description

# Version 1.3.0
### Released all data structure algorithms

# Version 1.2.0
### Released all searching algorithms

# Version 1.1.0
### Released all sorting algorithms

# Version 1.0.1
### Released bubble sort algorithm
### Bug Fixes

# Version 1.0
### Released pydone in beta
### Tested revold()


This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.