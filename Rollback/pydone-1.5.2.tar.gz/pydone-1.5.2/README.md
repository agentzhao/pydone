# pydone Package

# Made by Agentzhao and Revold

## How to Install
Make sure you have the latest version of **python** and **pip** installed.
```py -m pip install pydone```
To update:
```py -m pip install pydone==versionnumber```

## Version 1.5.2
Fixed Description

## Version 1.5.1
Added a 'l' somewhere
Added words

## Version 1.5.0
Added help functions
Added teaching modules

## Version 1.4.1
More Bug Fixes

## Version 1.4.0
Bug Fixes for Description

## Version 1.3.0
Released data structure algorithms

## Version 1.2.0
Released searching algorithms

## Version 1.1.0
Released sorting algorithms

## Version 1.0.1
Released bubble sort algorithm
Bug Fixes

## Version 1.0
Released pydone in beta
Tested revold()