__verison__ = "1.0.1"

name = "pydone"

def revold():
	print('done')
