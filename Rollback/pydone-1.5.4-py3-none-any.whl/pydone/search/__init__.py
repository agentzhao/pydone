def help():
    print('linear, binary, hashtable')

